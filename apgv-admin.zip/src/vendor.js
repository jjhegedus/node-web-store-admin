"use strict";
// Angular 2
require("@angular/platform-browser");
require("@angular/platform-browser-dynamic");
require("@angular/core");
require("@angular/common");
require("@angular/http");
require("@angular/router");
require("rxjs");
require("@angularclass/hmr");
// Other vendors for example jQuery, Lodash or Bootstrap
// You can import js, ts, css, sass, ...
//# sourceMappingURL=vendor.js.map