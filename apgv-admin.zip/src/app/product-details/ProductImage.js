"use strict";
var ProductImage = (function () {
    function ProductImage() {
    }
    return ProductImage;
}());
exports.ProductImage = ProductImage;
//# sourceMappingURL=ProductImage.js.map