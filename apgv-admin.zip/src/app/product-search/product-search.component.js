"use strict";
var core_1 = require("@angular/core");
var ProductsearchComponent = (function () {
    function ProductsearchComponent() {
        // Do stuff
    }
    ProductsearchComponent.prototype.ngOnInit = function () {
        console.log('ProductSearchComponent:ngOnInit()');
    };
    return ProductsearchComponent;
}());
ProductsearchComponent = __decorate([
    core_1.Component({
        selector: 'product-search',
        templateUrl: './product-search.component.html',
        styleUrls: ['./product-search.component.scss']
    }),
    __metadata("design:paramtypes", [])
], ProductsearchComponent);
exports.ProductsearchComponent = ProductsearchComponent;
//# sourceMappingURL=product-search.component.js.map