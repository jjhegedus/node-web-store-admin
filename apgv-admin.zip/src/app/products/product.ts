﻿export class Product {
    id: string;
    name: string;
    description: string;
    price: string;
}