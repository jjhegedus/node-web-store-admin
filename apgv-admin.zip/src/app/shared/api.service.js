"use strict";
var core_1 = require("@angular/core");
var ApiService = (function () {
    function ApiService() {
        this.title = '*** ADMIN - All Products Gone Viral - ADMIN ***';
    }
    return ApiService;
}());
ApiService = __decorate([
    core_1.Injectable()
], ApiService);
exports.ApiService = ApiService;
//# sourceMappingURL=api.service.js.map