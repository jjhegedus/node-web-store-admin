﻿import { Injectable } from '@angular/core';

@Injectable()
export class ApiService {
    title = '*** ADMIN - All Products Gone Viral - ADMIN ***';
}
